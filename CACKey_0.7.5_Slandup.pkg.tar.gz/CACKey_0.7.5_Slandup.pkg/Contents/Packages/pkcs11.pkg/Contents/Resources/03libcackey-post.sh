#!/bin/bash
chmod 755 /usr/local/lib/pkcs11
chown root:wheel /usr/local/lib/pkcs11
