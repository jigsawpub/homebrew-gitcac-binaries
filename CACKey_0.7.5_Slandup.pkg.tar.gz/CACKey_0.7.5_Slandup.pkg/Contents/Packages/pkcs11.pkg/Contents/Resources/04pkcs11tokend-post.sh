#!/bin/bash
chmod -R go+rX /Library/Security/tokend/PKCS11.tokend
chown -R root:wheel /Library/Security/tokend/PKCS11.tokend
